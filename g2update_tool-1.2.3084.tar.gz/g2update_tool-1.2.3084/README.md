#g2fwcheck
- operate G2Touch TSP get Version Info 

Requirement
---
    1. Linux x86 or x86_64 platform
    
Compilation
---
    Just type 'make' on the root directory os this projecct
    $ make

#g2updater
- operate G2Touch TSP upgrade Boot and FW

Requirement
---
    1. Linux x86 or x86_64 platform
    
Compilation
---
    Just type 'make' on the root directory os this projecct
    $ make